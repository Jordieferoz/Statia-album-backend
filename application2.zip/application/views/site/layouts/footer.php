    </div>
    </section>
    </main>
    <?php if (!isset($HIDE_CONTENT)) { ?>
      <footer style="margin-top: auto;">
        <div class="container">
          <p class="paragraph2 border-top footer-paragraph">© <?= date("Y") ?> Statia-tourism. All Rights
            Reserved.</p>
        </div>
      </footer>
    <?php } ?>
    </div>
    </body>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha256-m81NDyncZVbr7v9E6qCWXwx/cwjuWDlHCMzi9pjMobA=" crossorigin="anonymous"></script>
    <script>
      window.addEventListener('load', function() {
        document.getElementById("loading").style.display = "none";
      });
    </script>

    </html>