<?php

function sendsms($email, $vars)
{
    // $from = 'info@cubicdash.com';//'statiagallery@gmail.com';
    // $ci = &get_instance();

    // $ci->load->library('email');
    // $config = array();
    // $config['protocol']     = "smtp";
    // $config['smtp_host']    = "smtp.hostinger.com";
    // $config['smtp_user']    = $from;
    // $config['smtp_pass']    = "Info@CD4";//"Stati@dmin";
    // $config['smtp_port']    =  465;
    // $config['smtp_crypto']  = 'ssl';
    // $config['smtp_timeout'] = "";
    // $config['mailtype']     = "html";
    // $config['charset']      = "iso-8859-1";
    // $config['newline']      = "\r\n";
    // $config['wordwrap']     = TRUE;
    // $config['validate']     = FALSE;
    // $ci->email->initialize($config);

    // $message = 'Hello,\nPlease use this OTP for your account. \n\n OTP: ' . $vars['var1'];
    // $ci->email->set_newline("\r\n");
    // $ci->email->from($from);
    // $ci->email->to($email);
    // $ci->email->subject('Mail from Statia Pictures');
    // $ci->email->message($message);
    // if ($ci->email->send()) {
    //     echo 'Email sent.';
    // } else {
    //     echo ($ci->email->print_debugger());
    // }
}
