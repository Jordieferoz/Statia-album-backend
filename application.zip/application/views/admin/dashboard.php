<div class="center-dashboard">
    <div class="center-content">
        <h1 style="font-weight: 700;">Welcome Back</h1>
        <p>So, what are we adding today?</p>
    </div>
</div>