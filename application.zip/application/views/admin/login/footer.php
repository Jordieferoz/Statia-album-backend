
			<!-- Footer -->
            <div class="hk-footer-wrap container px-15">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <center>
                                <p style="color: white;">Powered by Statia-tourism | All Rights Reserved.</p>
                            </center>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- /Footer -->
        </div>
        <!-- /Main Content -->

    </div>
    <!-- /HK Wrapper -->
  
    <!-- jQuery -->
    <script src="<?php echo base_url() . 'assets/'; ?>vendors/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url() . 'assets/'; ?>vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url() . 'assets/'; ?>vendors/bootstrap/dist/js/bootstrap.min.js"></script>
	
	<!-- Owl JavaScript -->
    <script src="<?php echo base_url() . 'assets/'; ?>vendors/owl.carousel/dist/owl.carousel.min.js"></script>
	
	<!-- FeatherIcons JavaScript -->
    <script src="<?php echo base_url() . 'assets/'; ?>dist/js/feather.min.js"></script>
	
	<!-- Gallery JavaScript -->
    <script src="<?php echo base_url() . 'assets/'; ?>vendors/lightgallery/dist/js/lightgallery-all.min.js"></script>
    <script src="<?php echo base_url() . 'assets/'; ?>dist/js/froogaloop2.min.js"></script>
    
	<!-- Init JavaScript -->
    <script src="<?php echo base_url() . 'assets/'; ?>dist/js/lightgallery-all.js"></script>
    <script src="<?php echo base_url() . 'assets/'; ?>dist/js/landing-data.js"></script>
    <script src="<?php echo base_url() . 'assets/'; ?>dist/js/init.js"></script>
	</body>

</html>	