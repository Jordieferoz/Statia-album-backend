<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Statia Pictures | Admin</title>
    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?= base_url() ?>assets/site/images/favicon.png">

    <!-- Lightgallery CSS -->
    <link href="<?php echo base_url() . 'assets/'; ?>dist/css/lightgallery.css" rel="stylesheet" type="text/css">

    <!-- Custom CSS -->
    <link href="<?php echo base_url() . 'assets/'; ?>dist/css/style.css" rel="stylesheet" type="text/css">
    <style>
        .center {
            margin: auto;
            width: 60%;
            padding: 30px;
        }
    </style>
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="60" class="bg-image-admin">


    <!-- HK Wrapper -->
    <div class="center">