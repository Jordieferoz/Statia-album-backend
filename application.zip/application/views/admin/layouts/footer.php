
        </div>
        <!-- /Container -->
            <!-- Footer -->
            <div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 d-flex justify-content-end">
                            <p>Powered by Statia-tourism | All Rights Reserved.</p>
                        </div>
                    </div>
                </footer>
            </div>
            <!-- /Footer -->
        </div>
        <!-- /Main Content -->

    </div>
    <!-- /HK Wrapper -->


    <!-- <script src="https://code.jquery.com/jquery-3.5.0.js" integrity="sha256-r/AaFHrszJtwpe+tHyNi/XCfMxYpbsRg2Uqn0x3s2zc=" crossorigin="anonymous"></script> -->
    <!-- jQuery -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Slimscroll JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>dist/js/jquery.slimscroll.js"></script>

    <!-- Fancy Dropdown JS -->
    <script src="<?php echo base_url().'assets/'; ?>dist/js/dropdown-bootstrap-extended.js"></script>

    <!-- FeatherIcons JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>dist/js/feather.min.js"></script>

    <!-- Toggles JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/jquery-toggles/toggles.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>dist/js/toggle-data.js"></script>
	
	<!-- Counter Animation JavaScript -->
	<script src="<?php echo base_url().'assets/'; ?>vendors/waypoints/lib/jquery.waypoints.min.js"></script>
	<script src="<?php echo base_url().'assets/'; ?>vendors/jquery.counterup/jquery.counterup.min.js"></script>
	
	<!-- Morris Charts JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/raphael/raphael.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/morris.js/morris.min.js"></script>
	
	<!-- EChartJS JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/echarts/dist/echarts-en.min.js"></script>

    <!-- Data Table JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net-dt/js/dataTables.dataTables.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>dist/js/dataTables-data.js"></script>

	<!-- Sparkline JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/jquery.sparkline/dist/jquery.sparkline.min.js"></script>
	
	<!-- Vector Maps JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/vectormap/jquery-jvectormap-2.0.3.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>vendors/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>dist/js/vectormap-data.js"></script>

    <!-- Select2 JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/select2/dist/js/select2.full.min.js"></script>
    <script src="<?php echo base_url().'assets/'; ?>dist/js/select2-data.js"></script>
    <!-- Tinymce JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/tinymce/tinymce.min.js"></script>

    <!-- Tinymce Wysuhtml5 Init JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>dist/js/tinymce-data.js"></script>
	<!-- Owl JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/owl.carousel/dist/owl.carousel.min.js"></script>
	
	<!-- Toastr JS -->
    <script src="<?php echo base_url().'assets/'; ?>vendors/jquery-toast-plugin/dist/jquery.toast.min.js"></script>
    
    <!-- Init JavaScript -->
    <script src="<?php echo base_url().'assets/'; ?>dist/js/init.js"></script>
	<!-- <script src="<?php echo base_url().'assets/'; ?>dist/js/dashboard-data.js"></script> -->
	
</body>

</html>