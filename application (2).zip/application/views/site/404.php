<center>
    <h3>404! The page you are looking for is not found here. <a href="<?= base_url() ?>">Home</a></h3>
</center>